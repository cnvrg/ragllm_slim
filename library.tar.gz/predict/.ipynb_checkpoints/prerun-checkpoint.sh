git clone https://github.com/IntelLabs/fastRAG.git
cd fastRAG
pip install .
pip install libs/colbert