from fastrag.utils import safe_import

ImageDiffuserGenerator = safe_import("fastrag.image_generators.diffusers", "ImageDiffuserGenerator")
