from fastrag.utils import safe_import

LukeKGCreator = safe_import("fastrag.kg_creators.luke", "LukeKGCreator")
